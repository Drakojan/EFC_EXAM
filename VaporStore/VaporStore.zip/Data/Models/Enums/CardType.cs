﻿namespace VaporStore.Data
{
    public enum CardType
    {
        Debit, //0 
        Credit //1
    }
}